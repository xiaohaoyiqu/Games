@echo off
setlocal
cd /d "%~dp0"
chcp 65001 >nul
if not exist "%~dp0runtime\bin\java.exe" (
  echo Bundled runtime is missing. Extract the complete game ZIP again.
  exit /b 1
)
echo Using bundled Java runtime.
"%~dp0runtime\bin\java.exe" --enable-native-access=ALL-UNNAMED -cp "formula-workshop.jar;lib/*" com.f1car.Main %*
if errorlevel 1 (
  echo Game failed to start. Check the message above and your graphics driver.
  if "%~1"=="--smoke" exit /b 1
  pause
  exit /b 1
)
